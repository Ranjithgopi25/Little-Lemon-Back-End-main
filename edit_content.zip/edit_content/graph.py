from typing import TypedDict, List, Optional, Annotated
import operator
import json
import os
from langgraph.graph import StateGraph, END
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from .models import get_llm_client

from .schema import (
    DocumentStructure,
    EditorResult,
    ConsolidateResult,
    ConsolidatedBlockEdit,
    BlockEditResult,
    EditorFeedback
)

from .tools import (
    development_editor_tool,
    content_editor_tool,
    line_editor_tool,
    copy_editor_tool,
    brand_editor_tool,
)
from dotenv import load_dotenv

load_dotenv(".env", override=True)

# ----------------------------------------------------------------------
# GLOBAL LLM INSTANCE
# ----------------------------------------------------------------------
llm = ChatOpenAI(model="gpt-4o-mini", api_key=os.getenv("OPENAI_API_KEY"))

# ---------------------------------------------------------------------
# LLM (shared)
# # ---------------------------------------------------------------------
# llm = get_llm_client()

# ---------------------------------------------------------------------
# GRAPH STATE
# ---------------------------------------------------------------------
class SupervisorState(TypedDict):
    messages: List[BaseMessage]
    document: DocumentStructure
    selected_editors: List[str]
    editor_results: Annotated[List[EditorResult], operator.add]
    final_result: Optional[ConsolidateResult]
    # Sequential mode fields (optional)
    current_editor_index: Optional[int]  # For sequential execution
    thread_id: Optional[str]  # For checkpointing


# ---------------------------------------------------------------------
# EDITOR NODES (EXECUTE EXACTLY ONCE)
# ---------------------------------------------------------------------
def development_editor_node(state: SupervisorState) -> SupervisorState:
    print("RUNNING: development_editor_tool")

    raw_blocks = development_editor_tool.invoke(
        {"blocks": state["document"].blocks}
    )

    result = normalize_editor_output("development", raw_blocks)

    return {
        "editor_results": state["editor_results"] + [result]
    }


def content_editor_node(state: SupervisorState) -> SupervisorState:
    print("RUNNING: content_editor_tool")
    raw_blocks = content_editor_tool.invoke(
        {"blocks": state["document"].blocks}
    )

    result = normalize_editor_output("content", raw_blocks)

    return {
        "editor_results": state["editor_results"] + [result]
    }


def line_editor_node(state: SupervisorState) -> SupervisorState:
    print("RUNNING: line_editor_tool")
    raw_blocks = line_editor_tool.invoke(
        {"blocks": state["document"].blocks}
    )

    result = normalize_editor_output("line", raw_blocks)

    return {
        "editor_results": state["editor_results"] + [result]
    }


def copy_editor_node(state: SupervisorState) -> SupervisorState:
    print("RUNNING: copy_editor_tool")
    raw_blocks = copy_editor_tool.invoke(
        {"blocks": state["document"].blocks}
    )

    result = normalize_editor_output("copy", raw_blocks)

    return {
        "editor_results": state["editor_results"] + [result]
    }


def brand_editor_node(state: SupervisorState) -> SupervisorState:
    print("RUNNING: brand_editor_tool")
    raw_blocks = brand_editor_tool.invoke(
        {"blocks": state["document"].blocks}
    )

    result = normalize_editor_output("brand", raw_blocks)

    return {
        "editor_results": state["editor_results"] + [result]
    }


def normalize_editor_output(
    editor_type: str,
    raw_output,
) -> EditorResult:
    """
    Normalize editor tool output into EditorResult.
    Handles:
      - JSON string
      - list[dict]
      - {"blocks": list[dict]}
    """

    # ---------------------------
    # Step 1: Parse JSON string
    # ---------------------------
    if isinstance(raw_output, str):
        try:
            raw_output = json.loads(raw_output)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"{editor_type} editor returned invalid JSON"
            ) from e

    # ---------------------------
    # Step 2: Unwrap dict form
    # ---------------------------
    if isinstance(raw_output, dict):
        if "blocks" in raw_output:
            raw_blocks = raw_output["blocks"]
        else:
            raise TypeError(
                f"{editor_type} editor dict output missing 'blocks' key"
            )
    else:
        raw_blocks = raw_output

    # ---------------------------
    # Step 3: Validate list
    # ---------------------------
    if not isinstance(raw_blocks, list):
        raise TypeError(
            f"{editor_type} editor output must be a list of blocks, "
            f"got {type(raw_blocks)}"
        )

    # ---------------------------
    # Step 4: Convert to models
    # ---------------------------
    block_results = []
    for blk in raw_blocks:
        if not isinstance(blk, dict):
            raise TypeError(
                f"{editor_type} editor block must be dict, got {type(blk)}"
            )
        block_results.append(BlockEditResult(**blk))

    return EditorResult(
        editor_type=editor_type,
        blocks=block_results,
        warnings=[],
    )

# ---------------------------------------------------------------------
# MERGE NODE (FINAL STEP)
# ---------------------------------------------------------------------
def merge_node(state: SupervisorState) -> SupervisorState:
    print("MERGING EDITOR RESULTS")

    warnings: list[str] = []

    # Keyed by block id to ensure true merging
    blocks_by_id: dict[str, ConsolidatedBlockEdit] = {}

    for editor in state["editor_results"]:
        warnings.extend(editor.warnings)

        for blk in editor.blocks:

            # Initialize block once
            if blk.id not in blocks_by_id:
                blocks_by_id[blk.id] = ConsolidatedBlockEdit(
                    id=blk.id,
                    type=blk.type,
                    level=blk.level,
                    original_text=blk.original_text,
                    final_text=blk.suggested_text or blk.original_text,
                    has_changes=blk.has_changes,
                    editorial_feedback=EditorFeedback(
                        development=[],
                        content=[],
                        copy=[],
                        line=[],
                        brand=[],
                    ),
                )

            feedback = blocks_by_id[blk.id].editorial_feedback

            # If editor returned feedback, merge it
            if blk.feedback_edit:
                for sef in blk.feedback_edit:
                    if sef.editor == "development":
                        feedback.development.extend(sef.items)
                    elif sef.editor == "content":
                        feedback.content.extend(sef.items)
                    elif sef.editor == "copy":
                        feedback.copy.extend(sef.items)
                    elif sef.editor == "line":
                        feedback.line.extend(sef.items)
                    elif sef.editor == "brand":
                        feedback.brand.extend(sef.items)

    final = ConsolidateResult(
        blocks=list(blocks_by_id.values()),
        warnings=warnings,
    )

    return {"final_result": final}


# ---------------------------------------------------------------------
# SEQUENTIAL ROUTER (routes to single editor based on index)
# ---------------------------------------------------------------------
def route_sequential_editor(state: SupervisorState):
    """
    Route to the current editor based on current_editor_index.
    Used for sequential execution mode.
    """
    current_idx = state.get("current_editor_index", 0)
    selected_editors = state.get("selected_editors", [])
    
    if current_idx >= len(selected_editors):
        return "merge"  # All editors done, go to merge
    
    editor_name = selected_editors[current_idx]
    print(f"ROUTING TO SEQUENTIAL EDITOR: {editor_name} (index {current_idx})")
    
    # Map editor name to node name
    editor_node_map = {
        "development": "development_editor_tool",
        "content": "content_editor_tool",
        "line": "line_editor_tool",
        "copy": "copy_editor_tool",
        "brand": "brand_editor_tool",
    }
    
    return editor_node_map.get(editor_name, "merge")


# ---------------------------------------------------------------------
# SEQUENTIAL MERGE NODE (merges only current editor result)
# ---------------------------------------------------------------------
def sequential_merge_node(state: SupervisorState) -> SupervisorState:
    """
    Merge only the current editor's result for sequential flow.
    Reuses existing merge_node logic but filters to current editor only.
    """
    print("MERGING CURRENT EDITOR RESULT (SEQUENTIAL)")
    
    current_idx = state.get("current_editor_index", 0)
    editor_results = state.get("editor_results", [])
    
    if not editor_results:
        return {"final_result": None}
    
    # Get only the current editor's result (last one added)
    current_editor_result = editor_results[-1]
    
    # Create temporary state with only current editor for merging
    temp_state = {
        **state,
        "editor_results": [current_editor_result],  # Only current editor
    }
    
    # Reuse existing merge_node
    merged = merge_node(temp_state)
    
    return merged


# ---------------------------------------------------------------------
# ROUTER FOR SEQUENTIAL FLOW (after merge)
# ---------------------------------------------------------------------
def route_sequential_after_merge(state: SupervisorState):
    """
    After merging current editor result, interrupt for user approval.
    """
    current_idx = state.get("current_editor_index", 0)
    selected_editors = state.get("selected_editors", [])
    
    if current_idx >= len(selected_editors):
        return END
    
    # Interrupt for user approval
    return "__interrupt__"


# ---------------------------------------------------------------------
# SHARED CHECKPOINTER FOR SEQUENTIAL GRAPH
# ---------------------------------------------------------------------
# IMPORTANT: Use a single shared checkpointer instance so state persists
# across multiple graph instances (initial request and /next requests)
_sequential_checkpointer = MemorySaver()


# ---------------------------------------------------------------------
# BUILD SEQUENTIAL GRAPH (reuses existing graph nodes)
# ---------------------------------------------------------------------
def build_sequential_graph():
    """
    Build a sequential graph that runs editors one at a time with interrupts.
    REUSES all existing editor nodes, merge_node, and graph structure.
    
    Flow:
    1. route_sequential_editor -> routes to current editor node
    2. editor node -> runs current editor (reuses existing editor nodes)
    3. sequential_merge_node -> merges only current editor result
    4. route_sequential_after_merge -> interrupts for user approval
    5. Resume -> continues to next editor (when state updated externally)
    
    NOTE: All graph instances share the same checkpointer (_sequential_checkpointer)
    to ensure state persistence across requests.
    """
    graph = StateGraph(SupervisorState)
    
    # REUSE existing nodes
    graph.add_node("development_editor_tool", development_editor_node)
    graph.add_node("content_editor_tool", content_editor_node)
    graph.add_node("line_editor_tool", line_editor_node)
    graph.add_node("copy_editor_tool", copy_editor_node)
    graph.add_node("brand_editor_tool", brand_editor_node)
    graph.add_node("merge", sequential_merge_node)  # Sequential merge (filters to current editor)
    
    # Set entry point - use conditional routing directly
    graph.set_conditional_entry_point(
        route_sequential_editor,
        {
            "development_editor_tool": "development_editor_tool",
            "content_editor_tool": "content_editor_tool",
            "line_editor_tool": "line_editor_tool",
            "copy_editor_tool": "copy_editor_tool",
            "brand_editor_tool": "brand_editor_tool",
            "merge": "merge",  # All editors done
        }
    )
    
    # All editor nodes go to merge
    for node in [
        "development_editor_tool",
        "content_editor_tool",
        "line_editor_tool",
        "copy_editor_tool",
        "brand_editor_tool",
    ]:
        graph.add_edge(node, "merge")
    
    # After merge, route to interrupt or end
    graph.add_conditional_edges(
        "merge",
        route_sequential_after_merge,
        {
            "__interrupt__": "__interrupt__",  # Pause for user approval
            END: END,
        }
    )
    
    # Compile with SHARED checkpointer (critical for state persistence)
    return graph.compile(checkpointer=_sequential_checkpointer)
