import os
import logging
from typing import Union
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI



load_dotenv()

logger = logging.getLogger(__name__)

AI_ENDPOINT = 'https://genai-sharedservice-americas.pwcinternal.com'
AI_API_KEY = 'sk-wTvBeW1CBMG99KDy3lsS4Q'
AI_MODEL = 'azure.gpt-5.1'




def get_llm_client() -> Union[ChatOpenAI]:

    # ---------- TRY OPENAI ----------
    try:
        if not (AI_API_KEY and AI_MODEL):
            raise RuntimeError("OpenAI env vars missing")

        logger.info(f"Trying OpenAI model={AI_MODEL}")

        return ChatOpenAI(
            api_key=AI_API_KEY,
            model=AI_MODEL,
            openai_api_base=AI_ENDPOINT,  # REQUIRED if using custom endpoint
            temperature=0,
            max_tokens=32000
        )

    except Exception as openai_error:
        logger.warning(
            "OpenAI initialization failed. Falling back to Groq.",
            exc_info=True
        )


def llm() -> Union[ChatOpenAI]:
    """Backward-compatible alias."""
    return get_llm_client()
